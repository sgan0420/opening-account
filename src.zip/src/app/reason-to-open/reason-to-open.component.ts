import { Component } from '@angular/core';

@Component({
  selector: 'app-reason-to-open',
  templateUrl: './reason-to-open.component.html',
  styleUrl: './reason-to-open.component.css'
})
export class ReasonToOpenComponent {

}
